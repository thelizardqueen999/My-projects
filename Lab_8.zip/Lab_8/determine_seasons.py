#Program:Determine Seasons
#Programmer: Jessica Balog  
#Date: 11/5/2022
#Lab 8
################################################################

#Defining the function
def determine_season(input_temp):
    """Receives temp and returns the probable season"""
    season = ""

    if input_temp > 130 or input_temp < -20:
        season = "invalid"
    elif input_temp >= 90:
        season = "summer"
    elif input_temp >= 50 and input_temp < 70:
        season = "fall"
    elif input_temp < 50:
        season = "winter"
    else:
        season = ""
    return season

#printing the program
print(f"Program - Determine: Season:")
#Set the flag to true
repeat = True

while repeat:
    
    input_temp = (input("\nEnter the temperature(in Fahrenheit):"))
    input_temp = float(input_temp)
    season = determine_season(input_temp)
    print(f"Based on the temperature of {input_temp:.1f}, it is most likely {season}.")
    again = input("\nWould you like to enter another temperature? y/n?")
    if again == 'n':
        repeat = False 
    
print(f"\nThanks for using this program.  Goodbye!")

