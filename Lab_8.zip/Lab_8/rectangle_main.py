#Program:Rectangle_Main
#Programmer:Jessica Balog
#Date: 11/5/2022
#Lab 8

###############################################################

import rectangle_mod

#print program
print("Program - Find Area and Perimeter of Rectangle:")

#Set flag to true
repeat = True

while repeat:
    width = input("\nEnter the rectangle's width(inches): ")
    width = float(width)
    length = float(input("Enter the rectangle's lenth (inches):"))

    area = rectangle_mod.find_area(width, length)
    perimeter = rectangle_mod.find_perimeter(width, length)

    print(f"\nThe area is {area:.0f}")
    print(f"The perimeter is {perimeter:.0f}")
    again = input("\nWould you like to do another calculation? (y/n)")
    if again == 'n' :
        repeat = False

print(f"\nThanks for using this program. Goodbye.\n")


    
